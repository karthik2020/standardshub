document.addEventListener("DOMContentLoaded", () => {

    // ==========================================
    // Expand / Collapse Frameworks
    // ==========================================

    const headers = document.querySelectorAll(".section-header");

    headers.forEach((header) => {

        const section = header.closest(".section");
        if (!section) return;

        const sectionName = section.dataset.section;

        const items = header.nextElementSibling;

        if (!items || !items.classList.contains("section-items")) {
            return;
        }

        const savedState =
            localStorage.getItem(`section-${sectionName}`);

        const activeLink =
            section.querySelector(".nav-link.active");

        if (savedState !== null) {

            if (savedState === "open") {
                items.classList.remove("hidden");
                section.classList.add("expanded");
            } else {
                items.classList.add("hidden");
                section.classList.remove("expanded");
            }

        } else if (activeLink) {

            items.classList.remove("hidden");
            section.classList.add("expanded");

        } else {

            items.classList.add("hidden");

        }

        header.addEventListener("click", () => {
            console.log("clicked");
            items.classList.toggle("hidden");
            section.classList.toggle("expanded");

            localStorage.setItem(
                `section-${sectionName}`,
                items.classList.contains("hidden")
                    ? "closed"
                    : "open"
            );

        });
        if (activeLink) {

            requestAnimationFrame(() => {

                activeLink.scrollIntoView({

                    behavior: "instant"

                   

                });

            });

        }

    });


    // ==========================================
    // Sidebar Search Filter
    // ==========================================

    const searchInput =
        document.getElementById("standard-search");

    if (searchInput) {

        searchInput.addEventListener("input", (e) => {

            const searchTerm =
                e.target.value.toLowerCase().trim();

            const sections =
                document.querySelectorAll(".section");

            sections.forEach((section) => {

                const items =
                    section.querySelector(".section-items");

                const links =
                    section.querySelectorAll(".nav-link");

                let visibleCount = 0;

                links.forEach((link) => {

                    const code =
                        (link.dataset.code || "")
                            .toLowerCase();

                    const title =
                        (link.dataset.title || "")
                            .toLowerCase();

                    const matches =
                        searchTerm === "" ||
                        code.includes(searchTerm) ||
                        title.includes(searchTerm);

                    link.style.display =
                        matches ? "block" : "none";

                    if (matches) {
                        visibleCount++;
                    }

                });

                if (searchTerm === "") {

                    section.style.display = "";

                    const sectionName =
                        section.dataset.section;

                    const savedState =
                        localStorage.getItem(
                            `section-${sectionName}`
                        );

                    if (savedState === "open") {

                        items.classList.remove("hidden");
                        section.classList.add("expanded");

                    } else {

                        items.classList.add("hidden");
                        section.classList.remove("expanded");

                    }

                } else {

                    section.style.display =
                        visibleCount > 0
                            ? ""
                            : "none";

                    if (visibleCount > 0) {

                        items.classList.remove("hidden");
                        section.classList.add("expanded");

                    }

                }

            });

        });

    }


    // ==========================================
    // Restore Sidebar Scroll Position
    // ==========================================

    const sidebar =
        document.querySelector(".sidebar-scroll");

    if (sidebar) {

        const savedScroll =
            sessionStorage.getItem("sidebar-scroll");

        if (savedScroll) {

            sidebar.scrollTop =
                Number(savedScroll);

        }

        sidebar.addEventListener("scroll", () => {

            sessionStorage.setItem(
                "sidebar-scroll",
                sidebar.scrollTop
            );

        });

    }


    // ==========================================
    // Sidebar Ready
    // ==========================================

    document
        .querySelector(".sidebar-scroll")
        ?.classList.add("ready");

});